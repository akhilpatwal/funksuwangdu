module.exports = {
  apps : [{
    name: 'watchman',
    script: 'index_3.0.js',
    error_file: '/home/rohini/test/error.log',
    out_file: '/home/rohini/test/out.log',
    log_file: '/home/rohini/test/combined.log',
    // Options reference: https://pm2.keymetrics.io/docs/usage/application-declaration/
    autorestart: true,
    watch: ['rules'],
     node_args: "--expose-gc"
    //max_memory_restart: '1G',
   
  }],

};

module.exports = {
    'database': 'mongodb://localhost:27017/mydb',
    'port': 3030,
    'secret': ''
}
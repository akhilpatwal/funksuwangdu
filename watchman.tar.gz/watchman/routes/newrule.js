const router = require('express').Router();
const FS = require('fs');
const PATH = require('path');
const logger = require('../winstone');
var MongoClient = require('mongodb').MongoClient;

const DIR = {
	ROOT: PATH.join(__dirname),
	RULES: PATH.join(__dirname, "../rules/")
	
};

const FILES = {
        UID: PATH.join(DIR.ROOT, "../disablerules.json"),
		 elastic: PATH.join(DIR.ROOT, "../elasticdisablerules.json"),
		 promo: PATH.join(DIR.ROOT, "../promodisablerules.json"),
	
		
};

var UID={"rules":[]};
var elastic={"rules":[]};
var promo={"rules":[]};
try {
       if (FS.statSync(FILES.UID).isFile()) {
                UID = require(FILES.UID);
               
        }
		if (FS.statSync(FILES.elastic).isFile()) {
                elastic = require(FILES.elastic);
               
        }
		if (FS.statSync(FILES.promo).isFile()) {
                promo = require(FILES.promo);
               
        }

		
} catch(err) {
        console.log("## Error while loading previous Trigger Switch State: " + String(err));
        
}
var saveuid = function(UID){
        FS.writeFileSync(FILES.UID, JSON.stringify(UID));
};
var saveelastic = function(elastic){
        FS.writeFileSync(FILES.elastic, JSON.stringify(elastic));
};
var savepromo = function(promo){
        FS.writeFileSync(FILES.promo, JSON.stringify(promo));
};

const CONSTANTS = {
	RULE_TYPE: {
		STATEFUL: "stateful",
		STATELESS: "stateless"
	},
	ALERT_TYPE: {
		START: "alert_start",
		END: "alert_end"
	}
};
function smnpvarbindsdata(snmpdetails,enterpiseoid){
    
    var count=1

var varbinds=[]
snmpdetails.forEach(function(value){
    console.log("value",value)
    var test='{ "oid": '+'"'+enterpiseoid+'.'+count+'"'+', "type": "OctetString", "value":'+'"'+ value.IP+'"'+'}'
    const obj = JSON.parse(test)
    varbinds.push(obj)
    
    count++
  console.log(varbinds)
})

return varbinds
}
var rule_dirs = FS.readdirSync(DIR.RULES);
var RULE_DATA = {};
var DS_DATA  = {};
console.log("happy")

router.post('/create', (req, res, next) => {

const data1=req.body.data
 
const snmpstartraw=req.body.snmp
const snmpendraw=req.body.snmpend
	console.log(data1)
	//console.log(snmpstartraw)
	//console.log(snmpend)
	var url = "mongodb://localhost:27017/";

async function datadetails() {
    let db = await MongoClient.connect(url, {useNewUrlParser: true, useUnifiedTopology: true});
    let dbo = db.db("watchman");
     const response= await dbo.collection("datasources").find({name:data1.datasource}).toArray()
	const response1= await dbo.collection("alerttypes").find({name:data1.telegramsource}).toArray()
	const response2= await dbo.collection("alerttypes").find({name:data1.snmphost}).toArray()
	const response3= await dbo.collection("alerttypes").find({name:data1.emailsource}).toArray()
	return {response ,response1,response2,response3}
}

datadetails().then(resultdata => {
  var response=resultdata['response'];  // prints 60 after 4 seconds.
var response1=resultdata['response1']; 
var response2=resultdata['response2'];
console.log("res",response1)
if(response[0].datatype=="Influx"){
UID.rules.push(data1.rulename)
    saveuid(UID);
}
else if(response[0].datatype=="Elasticsearch"){
	elastic.rules.push(data1.rulename)
    saveelastic(elastic);
}
else if (response[0].datatype=="Prometheus"){
	promo.rules.push(data1.rulename)
    savepromo(promo);
}
var newdatatype = response[0].datatype;
var o = {} // empty Object
o.name= data1.rulename
o.run_time= data1.runtime,
o.datasource= newdatatype.toLowerCase(),
o.es_host= response[0].url,
o.index= data1.index,
o.type= data1.type,
o.start_poll_count=data1.startcount,
o.end_poll_count=data1.endcount,
o.alert_start = [];
o.alert_end=[]
           
             
			if (data1.telegramendmsg!=''){
				
							var telegramstart={
										"type": "telegram",
										"config": {
										"bot_token": response1[0].address,
										"room_id": response1[0].chatid
											},
												"tag":data1.telegramtag,
										"text": data1.telegramstartmsg
											}
							 var telegramend={
							 "type": "telegram",
							 "config": {
							 "bot_token": response1[0].address,
							 "room_id": response1[0].chatid
							},
							"tag":data1.telegramendtag,
									"text": data1.telegramendmsg
							}				
		      o["alert_start"].push(telegramstart)
              o["alert_end"].push(telegramend)
			}
			  
			    if (data1.snmphost!=''){
							var snmpoid=smnpvarbindsdata(snmpstartraw, response2[0].enterpriseoid)
							console.log("snmpoid",snmpoid)
							var snmpstart={
				 
								"type": "snmp",
								"config": {
										"host":response2[0].host,
										"enterprise_oid": response2[0].enterpriseoid,
										"agent_address": response2[0].agentaddress,
										"varbinds": snmpoid
								},
						  "tag":data1.snmptag,
								"text": ""
                
			}
			var snmpendoid=smnpvarbindsdata(snmpendraw, response2[0].enterpriseoid)
       console.log("snmpendoid",snmpendoid)
							var snmpend={
						 
										"type": "snmp",
										"config": {
												"host":response2[0].host,
												"enterprise_oid": response2[0].enterpriseoid,
												"agent_address": response2[0].agentaddress,
												"varbinds": snmpendoid
										},
								  "tag":data1.snmptag,
										"text": ""
								
							}
					o["alert_start"].push(snmpstart)
					o["alert_end"].push(snmpend)
			      }
				  if (data1.emailsource!=''){
							  var emailstart={
								"type": "email",
								"config" : {
										"host" : response3[0].address,
										"subject" : data1.emailsubject,
										"from_email" : data1.emailfrom,
										"to_email" : data1.emailto,
										"type" : "HTML"
								},
								"tag" : "",
								"text": data1.emailmsg
						}
						 var emailend={
								"type": "email",
								"config" : {
										"host" : response3[0].address,
										"subject" : data1.emailendsubject,
										"from_email" : response3[0].frommail,
										"to_email" : response3[0].frommail,
										"type" : "HTML"
								},
								"tag" : "",
								"text": data1.emailendmsg
						}
				o["alert_start"].push(emailstart)
			    o["alert_start"].push(emailend)
				  }
				  
//expression
var expression=req.body.expression

FS.mkdir(PATH.join(DIR.RULES,data1.rulename), { recursive: true }, function(err) {
	  if (err) {
		console.log(err)
	  } else {
	   
				let data = JSON.stringify(o);
				var newpath=DIR.RULES+data1.rulename
				FS.writeFile(PATH.join(newpath,"config.json"), data, (err) => {
					if (err) throw err;
					console.log('Data written to file');
				});
				FS.writeFile(PATH.join(newpath,"expression.js"), expression, (err) => {
					if (err) throw err;
					console.log('expression written to file');
				});
				FS.writeFile(PATH.join(newpath,"query"), data1.query, (err) => {
					if (err) throw err;
					console.log('expression written to file');
				});


    console.log("New directory successfully created.")
  }
})
})

		
    res.end("Post Successfully: \n");

});



module.exports = router;

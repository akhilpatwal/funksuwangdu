const router = require('express').Router();
const FS = require('fs');
const PATH = require('path');
const logger = require('../winstone');
const DIR = {
	ROOT: PATH.join(__dirname),
	RULES: PATH.join(__dirname, "../rules/")
	
};

const FILES = {
        UID: PATH.join(DIR.ROOT, "../iplist.json"),
		 PROIP: PATH.join(DIR.ROOT, "../promoclustertid.json"),
		  elasticdisable:PATH.join(DIR.ROOT,'../elasticdisablerules.json'),
		 influxdisablerules:PATH.join(DIR.ROOT,'../disablerules.json'),
		 promodisablerules:PATH.join(DIR.ROOT,'../promodisablerules.json'),
                   mysqldisablerule:PATH.join(DIR.ROOT,'../mysqldisablerule.json')
	
		
};
var PROIP={"clusterid":[]}
var UID={"IP":[]};
try {
        if (FS.statSync(FILES.UID).isFile()) {
                UID = require(FILES.UID);
		}
                if (typeof PROIP !="object" || Object.keys(PROIP).length == 0) {
                       PROIP = {"clusterid":[]};
                
        }
} catch(err) {
        console.log("## Error while loading previous Trigger Switch State: " + String(err));
        //logger.error("##Error while loading previous uid: " + String(err));
}
var saveuid = function(UID){
        FS.writeFileSync(FILES.UID, JSON.stringify(UID));
		console.log("save")
};
var savepropid = function(PROIP){
        FS.writeFileSync(FILES.PROIP, JSON.stringify(PROIP));
		console.log("save")
};
var readiplist = function(){
   var rawdata=     FS.readFileSync(FILES.UID);
    var iplist=JSON.parse(rawdata);
   return iplist
};
var readiplistpromp = function(){
   var rawdata=     FS.readFileSync(FILES.PROIP);
    var iplist=JSON.parse(rawdata);
   return iplist
};
var readdisablerulelist = function(){
	 
   var rawdata=     FS.readFileSync(FILES.UID);
    var iplist=JSON.parse(rawdata);
   return iplist
};
const CONSTANTS = {
	RULE_TYPE: {
		STATEFUL: "stateful",
		STATELESS: "stateless"
	},
	ALERT_TYPE: {
		START: "alert_start",
		END: "alert_end"
	}
};

var rule_dirs = FS.readdirSync(DIR.RULES);
var RULE_DATA = {};
var DS_DATA  = {};
console.log("happy")



router.post('/ip', (req, res, next) => {
console.log(req.body)
const data1=req.body
	var t=data1.IP
	
	var s=t.split(',')
	console.log(s)
	
	s.forEach(function(value){
		if (data1.alerttype==="Disable"){
		
     if((data1.datasource==="Elasticsearch")||(data1.datasource==="Influx")){	
		if (!UID.IP.includes(value)){
  UID.IP.push(value)
    saveuid(UID);
		}
	}
	if(data1.datasource==="Prometheus"){
				if (!PROIP.clusterid.includes(value)){
  PROIP.clusterid.push(value)
    savepropid(PROIP);
		}
		
	}
		}
		if (data1.alerttype==="Enable"){
			if((data1.datasource==="Elasticsearch")||(data1.datasource==="Influx")){	
			let dataen=readiplist();
			
			 var arr=dataen.IP
			 arr = arr.filter(item => !value.includes(item))
            console.log("rest",arr)
			
             let data = JSON.stringify(arr);
			  UID.IP=(JSON.parse(data))
             FS.writeFileSync(FILES.UID, JSON.stringify(UID, null, 2));
		
			}
			if((data1.datasource==="Prometheus")){	
			let dataen=readiplistpromp();
			
			 var arr=dataen.clusterid
			 arr = arr.filter(item => !value.includes(item))
            console.log("rest",arr)
			
             let data = JSON.stringify(arr);
			  PROIP.clusterid=(JSON.parse(data))
             FS.writeFileSync(FILES.PROIP, JSON.stringify(PROIP, null, 2));
		
			}
			
		}
		
		

});
	
	  console.log(data1)
		  
     
		
	//})
		
    res.end("success")

});


router.get('/list', (req, res, next) => {
    if (rule_dirs.length > 0) {
    	var RULE_LIST = [];
    	var i = 0;
    	rule_dirs.forEach(function(rule_d){
			var rule_folder = PATH.join(DIR.RULES, rule_d);
			var filename = PATH.basename(rule_folder);
			if (FS.statSync(rule_folder).isDirectory()) {
				RULE_DATA[rule_d]={};
				var rule_details = FS.readdirSync(rule_folder); //get rule folder file names
				if(rule_details.indexOf("config.json") != -1 && rule_details.indexOf("query") != -1){
					var config_data = FS.readFileSync(PATH.join(DIR.RULES,rule_d,"config.json"),"utf8");
					RULE_DATA[rule_d]['config'] = JSON.parse(config_data);
					RULE_LIST[i] = {};
					console.log(RULE_DATA[rule_d]['config']['name']);
					RULE_LIST[i]['name'] = RULE_DATA[rule_d]['config']['name'];
					RULE_LIST[i]['type'] = RULE_DATA[rule_d]['config']['type'];
					RULE_LIST[i]['run_time'] = RULE_DATA[rule_d]['config']['run_time'];
					RULE_LIST[i]['datasource'] = RULE_DATA[rule_d]['config']['datasource'];
					RULE_LIST[i]['start_poll_count'] = RULE_DATA[rule_d]['config']['start_poll_count'];
					RULE_LIST[i]['end_poll_count'] = RULE_DATA[rule_d]['config']['end_poll_count'];
					RULE_LIST[i]['dir'] = rule_d;
				}
			}
			i++
		});
  
		res.json({
            'success': true,
            'message': 'Rules list',
            'messagedetails':RULE_LIST
        });
	}
	else {
		//console.log("No Rules found!");
		logger.error("##No Rules found!");
		
	}


});


router.get('/detail/:rule_name', (req, res, next) => {


    if (rule_dirs.length > 0) {
		var rule_d=req.params.rule_name;
		var rule_folder = PATH.join(DIR.RULES, rule_d);
		var filename = PATH.basename(rule_folder);
		RULE_DATA = {};
		if (FS.statSync(rule_folder).isDirectory()) {
			RULE_DATA[rule_d]={};
			var rule_details = FS.readdirSync(rule_folder); //get rule folder file names
			if(rule_details.indexOf("config.json") != -1 && rule_details.indexOf("query") != -1){
				var config_data = FS.readFileSync(PATH.join(DIR.RULES,rule_d,"config.json"),"utf8");
				RULE_DATA['config'] = JSON.parse(config_data);
			}
		}

  
		res.json({
            'success': true,
            'message': 'Rules list',
            'rule':RULE_DATA
        });
	}
	else {
		//console.log("No Rules found!");
		logger.error("##No Rules found!");
		
	}


});

router.get('/disableipcount', (req, res, next) => {
	var countip={}
	var rawdatarules3= FS.readFileSync(FILES.elasticdisable);
         diselastic=JSON.parse(rawdatarules3);
		 countip.elastic=diselastic.rules.length
		 
		var  rawdatarules2=     FS.readFileSync(FILES.influxdisablerules);
         disinflux=JSON.parse(rawdatarules2);
		 countip.influx=disinflux.rules.length
      
	    var rawdatarules1=     FS.readFileSync(FILES.promodisablerules);
        dispromp=JSON.parse(rawdatarules1);
		countip.promp=dispromp.rules.length
		
		  var rawdatarules3=     FS.readFileSync(FILES.mysqldisablerule);
        dismysql=JSON.parse(rawdatarules3);
                countip.mysql=dismysql.rules.length

		 var ipelkinflux=FS.readFileSync(FILES.UID)
		var obj = JSON.parse(ipelkinflux);
		  	var awdatarules1=FS.readFileSync(FILES.PROIP);
			
			var profile = JSON.parse(awdatarules1);
						profile.clusterid.forEach(function(table) {
			  obj.IP.push(table)
			console.log(table)
						  
			})
			
		  disip=obj
		  
	countip.ip=disip.IP.length


  
		res.json({
            'success': true,
            'message': 'IP LIST',
            'messagedetails':countip
        });
	
	
});
router.get('/disablerule/:datasource', (req, res, next) => {
	var enabledatasource=req.params.datasource;
	console.log("enabledatasource",enabledatasource)
	 var disrules
	   var rawdatarules
	   var ipdisablelist ={"IP":[]}
	  
			
						  
	   
	if(enabledatasource=="elasticsearch"){
	rawdatarules=     FS.readFileSync(FILES.elasticdisable);
         disrules=JSON.parse(rawdatarules);
           disrules.rules.splice(0, 0, req.rawHeaders[9])
	}
		else if(enabledatasource=="influx"){
	rawdatarules=     FS.readFileSync(FILES.influxdisablerules);
         disrules=JSON.parse(rawdatarules);
         disrules.rules.splice(0, 0, req.rawHeaders[9])
	}
	else if(enabledatasource=="prometheus"){
	rawdatarules=     FS.readFileSync(FILES.promodisablerules);
        disrules=JSON.parse(rawdatarules);
          disrules.rules.splice(0, 0, req.rawHeaders[9])
	}
        else if(enabledatasource=="mysql"){
        rawdatarules=     FS.readFileSync(FILES.mysqldisablerule);
        disrules=JSON.parse(rawdatarules);
        }
       
	else if(enabledatasource=="disableip"){
		
		 var ipelkinflux=FS.readFileSync(FILES.UID)
		var obj = JSON.parse(ipelkinflux);
		  	var awdatarules1=FS.readFileSync(FILES.PROIP);
			
			var profile = JSON.parse(awdatarules1);
						profile.clusterid.forEach(function(table) {
			  obj.IP.push(table)
			console.log(table)
						  
			})
			
		  disrules=obj
	           disrules.IP.splice(0, 0, req.rawHeaders[9])	  
						  
			
			
       
	}
	
	
var rulelist=JSON.stringify(disrules)


  console.log(rulelist)
  

		res.json({
            'success': true,
            
			'messagedetails':rulelist,
			
        });
		
	
	
});




module.exports = router;

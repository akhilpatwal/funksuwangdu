var MongoClient = require('mongodb').MongoClient;
//Create a database named "mydb":
var url = "mongodb://localhost:27017/";
/*MongoClient.connect(url, {useNewUrlParser: true, useUnifiedTopology: true}, function(err, db) {
  if (err) throw err;
  console.log("Database created!");
  var dbo = db.db("watchman");
  //Find the first document in the customers collection:
  var count=dbo.collection("datasources").findOne({}, function(err, result) {
    if (err) throw err;
	console.log("result",result)
    db.close();      
      return result;

  
});
console.log("yyy",count)
})
console.log(resultdaat)
*/
var finalMovies = "";
async function listCars() {
    let db = await MongoClient.connect(url, {useNewUrlParser: true, useUnifiedTopology: true});
    let dbo = db.db("watchman");
     const response= await dbo.collection("datasources").find({}).toArray()
	const response1= await dbo.collection("alerttypes").find({}).toArray()
	return {response ,response1}
}

listCars().then(cars => {
  var rea=cars["response"];
console.log(rea[0])  // prints 60 after 4 seconds.
});

console.log("p",finalMovies)
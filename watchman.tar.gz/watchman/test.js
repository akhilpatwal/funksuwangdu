var snmp = require('net-snmp');

var session = snmp.createSession ("10.92.200.81", "public");

var enterpriseOid = "1.3.6.1.4.1.2000.1.1";

var varbinds = [
        { oid: "1.3.6.1.4.1.2000.1.1.1", type: snmp.ObjectType.OctetString, value: "10.5.252.53" },
        { oid: "1.3.6.1.4.1.2000.1.1.2", type: snmp.ObjectType.OctetString, value: "Logstash" },
        { oid: "1.3.6.1.4.1.2000.1.1.3", type: snmp.ObjectType.OctetString, value: "10.5.12.12" },
        { oid: "1.3.6.1.4.1.2000.1.1.4", type: snmp.ObjectType.OctetString, value: "MAA-10.5.12.12" },
        { oid: "1.3.6.1.4.1.2000.1.1.5", type: snmp.ObjectType.OctetString, value: "TEST ALERT | MyAirtelApp | key : -1 | Failure Percentage: 0.0028" },
        { oid: "1.3.6.1.4.1.2000.1.1.6", type: snmp.ObjectType.OctetString, value: "2" },
        { oid: "1.3.6.1.4.1.2000.1.1.7", type: snmp.ObjectType.OctetString, value: "3" },
        { oid: "1.3.6.1.4.1.2000.1.1.8", type: snmp.ObjectType.OctetString, value: "MAA" }
];
var agentAddress = "10.56.139.182";
var options = {agentAddr: agentAddress, upTime: 1000};

session.trap(enterpriseOid, varbinds, agentAddress, function (error) {
        if (error) {
                console.log("Error: ", error);
        } else {
                console.log("Successfully generated Trap!");
        }
});

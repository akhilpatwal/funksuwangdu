var snmp = require('net-snmp');
const logger1 = require('../winstone');
module.exports = function(logger){

	var sender = {
		name: "snmp",
		required: ["host"]
	};

	sender.init = function(){
		//console.log("SNMP Plugin Loaded successfully!");
		logger1.info("SNMP Plugin Loaded successfully!");
	};

	sender.sendAlert = function(config, alert_text,alert_type,job_id,tag,rule_type ,callback){
		console.log("inside snmp................");
		var tag=tag;
        var rule_type=rule_type;
		var enterpriseOid = config.enterprise_oid ? config.enterprise_oid : "1.3.6.1.4.1";
		console.log("enterpriseOid", enterpriseOid);
		var varbinds = config.varbinds ? config.varbinds : [];

		// Replace Data Types
		for (var j=0; j < varbinds.length; j++) {
			if (varbinds[j].type == "OctetString") {
				varbinds[j].type = snmp.ObjectType.OctetString;
			}
			if (varbinds[j].type == "Boolean") {
				varbinds[j].type = snmp.ObjectType.Boolean;
			}
			if (varbinds[j].type == "Integer") {
				varbinds[j].type = snmp.ObjectType.Integer;
			}
		}
		var agentAddress = config.agent_address ? config.agent_address : "127.0.0.1";

		var debug_var = {
			enterpriseOid: enterpriseOid,
			varbinds: varbinds,
			agentAddress: agentAddress
		};
		console.log("snmp console data", JSON.stringify(debug_var));
		 for ( var x=0; x < config.host.length; x++) {
                        var host = config.host[x] ? config.host[x] : "localhost";
                        var community = config.community ? config.community : "public";
                        var session = snmp.createSession(host, community);

			session.trap(enterpriseOid, varbinds, agentAddress, function (error) {
			console.log("inside seesion trap in snmp ", error)
			//console.log("*** SNMP DEBUG: ", JSON.stringify(debug_var));			
			logger1.info("*** SNMP DEBUG: "+rule_type+","+tag+","+job_id+","+alert_type+","+ JSON.stringify(debug_var));
				if (error) {
			//console.log("*** SNMP ERROR: ", String(error));	
		logger1.error("*** SNMP ERROR: ", String(error));
					callback(error);
				} else {
					callback(null);
				}
			});
/*
		session.trap(enterpriseOid, varbinds, function (error) {
			if (error) {
				callback(error);
			} else {
				callback(null);
			}
		});
*/
		}
	};
	return sender;
};

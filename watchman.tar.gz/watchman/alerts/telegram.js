var request = require('request');

const logger1 = require('../winstone');
//process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

module.exports = function(logger){

	var telegram = {
		name: "telegram",
        required: ["bot_token", "room_id"]
	};
    
    telegram.init = function(){
        //console.log("Telegram Loaded successfully!");
		//logger1.info("Telegram Loaded successfully!");
		//console.log('Path of file in parent dir:', require('path').resolve(__dirname, './winstone.js'));
		logger1.info("Telegram Loaded successfully!");
    };
    
    telegram.sendAlert = function(config,alert_text,alert_type,job_id,tag,rule_type, callback){
        var api_url = "https://api.telegram.org/bot" + config.bot_token + "/sendMessage";
      //  var api_url = "https://149.154.167.220:443/bot" + config.bot_token + "/sendMessage";
        console.log("alert_text",alert_text)
        var tag=tag;
        var rule_type=rule_type;
        var request_data = {
            chat_id: config.room_id,
            text: alert_text,
            parse_mode: "HTML",
            disable_web_page_preview: true,
        };

        var options = {
            url: api_url,
          //  proxy: 'http://2391459:eLa3N4I~@172.27.2.163:4145',
            headers: {
                "Content-Type" : "application/json"
            },
            body: JSON.stringify(request_data)
        };
        request.post(options, function(error, response, body){
            if (error) {
		//console.log(error);
	         logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);

		logger1.error("telegram error"+error);
                callback(error);
            }
            else {
                 logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);

                callback(null);
            }
	  console.log(rule_type);
	//  logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);
        });
    };

	return telegram;
	
};

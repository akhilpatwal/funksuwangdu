var request = require('request');

const logger1 = require('../winstone');
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

module.exports = function(logger){

	var slack= {
		name: "slack",
        required: ["bot_token", "room_id"]
	};
    
    slack.init = function(){
       
		logger1.info("SLACK Loaded successfully!*********8");
    };
    
    slack.sendAlert = function(config,alert_text,alert_type,job_id,tag,rule_type, callback){
        
        var api_url = "https://slack.com/api/chat.postMessage" 
        var tag=tag;
        var rule_type=rule_type;
        var request_data = {
            channel: config.room_id,
            text: alert_text,
            parse_mode: "HTML",
            disable_web_page_preview: true,
        };
const slackToken = 'xoxb-2363290466224-2341878579861-kkrQLF9vG9yEQweptjNA4Fd9';
        var options = {
            url: api_url,
          
            headers: {
                "Content-Type" : "application/json",
				"Authorization": `Bearer ${config.bot_token}`
            },
            body: JSON.stringify(request_data)
        };
        request.post(options, function(error, response, body){
            if (error) {
		
	         logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);

		logger1.error("slackerror"+error);
                callback(error);
            }
            else {
                 logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);

                callback(null);
            }
	  console.log(rule_type);
	
        });
    };

	return slack;
	
};


var request = require('request')
const PATH = require('path');
const FS = require('fs');
const logger1 = require('../winstone');
module.exports = function(logger){
	var servicenow = {
		name: "servicenow"
               
        
	};
const DIR = {
        ROOT: PATH.join("../watchman"),

};
const FILES = {
        UID: PATH.join(DIR.ROOT, "sysy.json")
};
var UID=[];
   var saveuid = function(UID){
        FS.writeFileSync(FILES.UID, JSON.stringify(UID));
};
 filePath =PATH.join(__dirname,'../../watchman/sysy.json');
        var rawdata=   FS.readFileSync(filePath);
        var result=JSON.parse(rawdata);

    servicenow.init = function(){
       
		logger1.info("SERVICENOW Loaded successfully!");
    };
    
    servicenow.sendAlert = function(config,alert_text,alert_type,unique_alert_id,job_id,tag,rule_type, callback){
     var saveid;
 	 var  savesys_id;
      var uniqueid=unique_alert_id+job_id;
           console.log("testing");
       if (alert_type=="alert_end"){
       
          for (var i=0; i < result.length; i++){
                               if (result[i].id === uniqueid){
                               saveid=result[i].id;
                        savesys_id=result[i].sys_id
                          console.log("uid",saveid)
                                        }
}

           var api_url = "https://airtelafricauat.service-now.com/api/now/table/incident/"+savesys_id;
       }
else{
     
        var api_url = "https://airtelafricauat.service-now.com/api/now/table/incident";


}	 var tag=tag;
     
   var rule_type=rule_type;

	console.log("testing");
		  var date=config.date;	
                  var node =config.node;
		  var type=config.type;
		  var resource=config.resource;
		  var metric_name=config.metric_name;
		  var resolution_state=config.resolution_state;
		  var source=config.source;
		  var dp_ip=config.dp_ip;
		  var dr_ip=config.dr_ip;
                  var source=config.source;
		  var country_code=config.country_code;
		  var caller_id=config.caller_id;
                  var targettype=config.targettype;
		  var priority=config.priority;
		  var short_description=config.short_description;
		 var text=alert_text;
		var description=config.description;
		var cmdb_ci=config.cmdb_ci;
		var state=config.state;
		var u_metric_name=config.u_metric_name;
		var u_source=config.u_source;
		
			

        var request_data = {
         caller_id: caller_id,
	priority: priority,
	short_description: short_description,
	cmdb_ci: cmdb_ci,
	description: text,
	state: state,
	u_metric_name: u_metric_name,
	u_source: u_source
        };
   
     var username="aiops";
     var   password ="12345";

                        auth = "Basic " + Buffer.from(username + ":" + password).toString("base64");

        var options = {
            url: api_url,
              proxy: 'http://aiops:cfvg%401q1@172.23.12.67:4145',
            headers: {
                "Content-Type" : "application/json",
				 "Authorization" : auth
            },
            body: JSON.stringify(request_data)
        };
  
 if(alert_type=="alert_end"){

     request.put(options, function(error, response, body)
    {
         console.log("teynnnm",unique_alert_id);

	console.log("testing1",options);

        if (error) {

                logger1.error("SNMP error"+error);
                callback(error);
            }
            else {
			  callback(null);
            }
    logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);
        });
}
else{
 request.post(options, function(error, response, body)
  {
         console.log("teym",unique_alert_id);
             console.log("testing11",options);

            if (error) {
		
		logger1.error("SNMP error"+error);
                callback(error);
            }
            else {
   
						var jsontest =JSON.parse(body);
                                                  var value=jsontest.result.sys_id;
     
    					var formate="{"+'"'+"id"+'"'+":"+'"'+unique_alert_id+job_id+'"'+","+'"'+"sys_id"+'"'+":"+'"'+value+'"'+"}"
                                   
                                    var obj =formate
                                      UID.push(JSON.parse(obj))
                                   saveuid(UID);
   
                callback(null);  
            }
	  
	  logger1.info(rule_type+","+tag+","+job_id+","+alert_type+","+body);
        });
}
    };

	return servicenow;
	
};



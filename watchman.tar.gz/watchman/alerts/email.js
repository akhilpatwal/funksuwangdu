var nodemailer = require('nodemailer');
const logger1 = require('../winstone');
module.exports = function(logger){

	var email = {
		name: "email",
        required: ["host", "from_email", "to_email", "subject"]
	};
    
    email.init = function(){
        //console.log("Email Plugin Loaded successfully!");
		logger1.info("Email Plugin Loaded successfully!");
    };
    
//    email.sendAlert = function(config, alert_text, callback){
      email.sendAlert = function(config, alert_text,alert_type,job_id,tag,rule_type ,callback){
        if (config.username) {
            config.username = config.username.replace("@", "%40");
        }
       // var transporter = nodemailer.createTransport("smtp://"+(config.username ? config.username+":"+config.password+"@" : "")+config.host);
       var transporter = nodemailer.createTransport({
                host: config.host,
                port: 25
	});
	
        var mailOptions = {
            from: config.from_email,
            to: config.to_email,
            subject: config.subject,
        };
        
        if (config.type && config.type.toUpperCase() == "HTML") {
            mailOptions.html = alert_text;
        }
       
	console.log("final_mail request", mailOptions); 
        transporter.sendMail(mailOptions, function(error, info){
            if(error){
                callback(error);
		logger1.error("error while sending email" + error);
            } else {
		info.text_message=alert_text;
		logger1.info("*** Email Debug: "+rule_type+","+job_id+","+alert_type+","+ JSON.stringify(info));
                callback(null);
            }
        });
    };

	return email;
};

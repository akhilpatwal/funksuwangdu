(function()
{
		
	var code_bucket = response;
	var total = code_bucket.hits.total.value;
	if(total > 1){
		
					  "//add ${ALERT_ID} for unique alert"
						alertUp();
	}
	else{
					   "//add ${ALERT_ID} forn unique alert"
						alertDown();
	}

}
)()
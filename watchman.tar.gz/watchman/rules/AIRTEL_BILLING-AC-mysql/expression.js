(function(){
      


          var code_bucket = response; 
	console.log("total",code_bucket);
        var keys = [""];
        //var keys = ["success","You have entered an invalid otp. please note that you are allowed maximum of 3 incorrect attempts","You have exceeded the maximum limit of incorrect entries. please regenerate new otp to complete registration."];
        //console.log("2nd",keys);

				if (code_bucket > 4) {
					//console.log("in if")
				 	alertUp();
				}
				else{
					alertDown();
				}
               
})()

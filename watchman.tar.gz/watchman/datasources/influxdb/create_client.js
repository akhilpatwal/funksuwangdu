const Influx = require('influx');

function createClient(config) {
	var influx = new Influx.InfluxDB({
	        host: config.host,
        	database: config.in_database,
		username: config.username,
		password: config.password
        });
	influx.ping(3000).then(hosts => {
  		hosts.forEach(host => {
			if (host.online) {
				console.log(`Connected to InfluxDB at ${host.url.host} for rule `+config.name+`.`)
			} else {
				console.log(`${host.url.host} is Unavailable for rule `+config.name+`!!`)
			}
		})
	})
	return influx;
}

module.exports.createClient = createClient;


function queryClient(client, rule_data, query, success_callback, error_callback) {
	var parser = require('./query_parser.js');
	var start_time = Date.now();
	var query_final = parser.queryParser(query);
	console.log(query_final);
        client.query(query_final).then(function(response){
                var time_taken = (Date.now() - start_time)/1000;
                if (time_taken > 1) {
                        console.log("!!! WARNING: Took "+time_taken+" seconds for " + rule_data["config"]["measurement"]);
                }
                console.log("<<< Took seconds: ", time_taken);
                success_callback(response);
        }, function(error_response){
                var time_taken = (Date.now() - start_time)/1000;
                if (time_taken > 1) {
                        console.log("!!! WARNING: Took "+time_taken+" seconds for " + rule_data["config"]["measurement"]);
                }
                console.log("<<< Took seconds: ", time_taken);
                error_callback(error_response);
        });	
}

module.exports.queryClient = queryClient;

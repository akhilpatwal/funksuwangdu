let RequestClient = require("reqclient").RequestClient;
var request = require('request');

function createClient(config) {
	var link="http://"+config.host+"/api/v1/"
      var  prometeus = new RequestClient({
    baseUrl: link
 });
 request.get(prometeus.baseUrl, function(error, response, body){
            if (error) {
			console.error(config.host+' is Unavailable for rule '+config.name+'!!'+error);
		} else {
			console.log('Connected to prometheus at '+config.host+' for rule '+config.name+'.');
		}
	  
        });
		return prometeus;

}

module.exports.createClient = createClient;


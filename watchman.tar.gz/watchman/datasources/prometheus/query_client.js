const logger = require('../../winstone');

function queryClient(client, rule_data, query, success_callback, error_callback) {
        var start_time = Date.now();

    var fs = require('fs'),
    path = require('path'),
    
        filePath = path.join(__dirname,'../../promoclustertid.json');
        var rawdata=     fs.readFileSync(filePath);
        var iplist=JSON.parse(rawdata);
        console.log("iplist", iplist);

        filePathrules = path.join(__dirname,'../../promodisablerules.json');
        var rawdatarules=     fs.readFileSync(filePathrules);
        var disrules=JSON.parse(rawdatarules);
        console.log("disablerules",disrules);
        console.log("Hello World");

        var rulename= rule_data["config"]["name"];
        console.log("rulename",rulename);
       if (disrules.rules.includes(rulename)){
                              var ipstring
                                iplist.clusterid.forEach(function(value,index){
    						 console.log(value,index)
 								    if (index===0){
										         ipstring=value
									     }
								     else{
										         ipstring=ipstring +"|"+value
								     }
 							});
                                            var s=query.split('@')
                                              query =s[0]+"clusterID!~"+'"'+ipstring+'"'+s[1]
        }
      else {
            query=query.replace("@","")
       }
	console.log("query",query)
                   var newquery=encodeURIComponent(query)
                   var finalquery="/query?pretty=true&query="+newquery
                //	console.log("finalquery",finalquery)
             	client.get(finalquery)
           		  .then(function(response) {
					    console.log("reasponse",response.data.result); 
						success_callback(response);	// REST responses are parsed as JSON objects
  						})
			  .catch(function(err) {
					    console.error(err);
				        	error_callback(error_response);
 						});


}

module.exports.queryClient = queryClient;


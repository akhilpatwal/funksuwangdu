var mysql = require('mysql')

function createClient(config) {
//   console.log(config)
	
	var connection = mysql.createConnection({
						  host: 'localhost',
						  user: 'root',
						  password: 'root123',
						  database: 'student'
						})

	
        connection.connect(function(err) {
        if (err) {
			console.error(config.host+' is Unavailable for rule '+config.name+'!!');
		} else {
			console.log('Connected to mysql at '+config.host+' for rule '+config.name+'.');
		}
       
    });
	return connection ;
}

module.exports.createClient = createClient;



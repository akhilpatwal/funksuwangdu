var moment = require('moment');
function queryParser(query) {
	
	var PARAM = {
                CURRENT_TIME_MS: new Date().getTime()
        };
	var getExprMatches = function(expr){
		return expr.match(/\$\{([^\{\}]*)\}/gi);
	};
	var matches = getExprMatches(query);
	
        if (matches) {
              	matches.forEach(function(matched){
			var round = /(\d+)(.+)\/\2/gmi.exec(matched);
		       
		        if (round) {
				var num = round[1];
				var round_to = round[2];
				var start_time = new Date(moment().subtract(num, round_to).startOf(round_to)).getTime();
				var end_time =  new Date(moment().subtract(num, round_to).endOf(round_to)).getTime();
				console.log('start: '+start_time+' end: '+end_time);
				var param_val = start_time+"ms AND time < "+end_time+"ms";
				console.log(param_val);
				query = query.replace(matched, param_val);
				
        		}
			else {
				query = query;
			}
		});
        }
	
	return query
}

module.exports.queryParser = queryParser;


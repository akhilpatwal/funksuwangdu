function queryClient(client, rule_data, query, success_callback, error_callback) {
	var parser = require('./query_parser.js');
	var start_time = Date.now();
	var query_final = parser.queryParser(query);
	console.log(query_final);
          client.query(query_final, function (err,response, fields) {
  if (err){

   error_callback(err);
    }
   else{
     success_callback(response);
    }
})	
}

module.exports.queryClient = queryClient;


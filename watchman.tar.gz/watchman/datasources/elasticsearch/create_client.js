const ES = require('elasticsearch');

function createClient(config) {
        var elastic = new ES.Client({
	        host: config.es_host ? config.es_host : "localhost:9200",
        	log: config.es_log_level ? config.es_log_level : "info"
	});
	elastic.ping({
		requestTimeout: 3000,
	}, function(error) {
		if (error) {
			console.error(config.es_host+' is Unavailable for rule '+config.name+'!!');
		} else {
			console.log('Connected to Elasticsearch at '+config.es_host+' for rule '+config.name+'.');
		}
	});
        return elastic;
}

module.exports.createClient = createClient;

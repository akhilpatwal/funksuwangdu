function queryClient(client, rule_data, query, success_callback, error_callback) {


         var fs = require('fs'),
        path = require('path'),

        filePath = path.join(__dirname,'../../iplist.json');
        var rawdata=     fs.readFileSync(filePath);
        var iplist=JSON.parse(rawdata);
        console.log("iplist", iplist);

        filePathrules = path.join(__dirname,'../../elasticdisablerules.json');
        var rawdatarules=     fs.readFileSync(filePathrules);
        var disrules=JSON.parse(rawdatarules);
     //   console.log("disablerules",disrules);
       // console.log("Hello World");

        var rulename= rule_data["config"]["name"];
       // console.log("rulename",rulename);

        var start_time = Date.now();
	var index = rule_data["config"]["index"]
          if (disrules.rules.includes(rulename)){
                         var ipstring
                         iplist.IP.forEach(function(value){
   					 ipstring='{"match_phrase": {"IP.keyword": { "query":"'+value.ip+'"}} }'
					 var str = JSON.parse(ipstring)
                  //              console.log(query)
                             //  console.log("ipstring",str);

                                      var data=JSON.parse(query)
                                 for ( key in data["query"]["bool"]) {
                             //     console.log("key",key)
                                                if (key==="must_not"){
           
                                                                var obj = JSON.parse(JSON.stringify(data))
                                                                  obj["query"]["bool"]["must_not"].push(str)
                                                                    query = JSON.stringify(obj);
                                              //        console.log('match!', query); // do stuff here!
       }

}
				});
              //  console.log("ipstring",str);
             
        }
//      console.log("afterquery",query);
	client.search({
                index: index,
                body: query
        }).then(function(response){
                var time_taken = (Date.now() - start_time)/1000;
                if (time_taken > 1) {
                        console.log("!!! WARNING: Took "+time_taken+" seconds for " + index);
                }
                console.log("<<< Took seconds: ", time_taken);
                success_callback(response);
        }, function(error_response){
                var time_taken = (Date.now() - start_time)/1000;
                if (time_taken > 1) {
                        console.log("!!! WARNING: Took "+time_taken+" seconds for " + index);
                }
                console.log("<<< Took seconds: ", time_taken);
                error_callback(error_response);
        });
}

module.exports.queryClient = queryClient;

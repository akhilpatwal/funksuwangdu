#!/bin/bash

read_data_from_elastic=$(curl -s -XPOST http://172.29.8.87:9200/ip_process_config/_search -H 'Content-Type: application/json'  -d '{"size" :1000,"query": { "bool": { "must_not": [ { "match": { "Device Type": "DS Computer" } } ] } }}' | jq '.hits.hits')

echo "$read_data_from_elastic" >/elastic_data/services/new_watchman_19-3-20/watchman/ip.json

read_no_process_data_from_elastic=$(curl -s -XPOST http://172.29.8.87:9200/ip_process_config/_search -H 'Content-Type: application/json'  -d '{ "size":1000, "query": { "bool": { "must_not": [ { "term": { "ProcessType.keyword": "" } }, { "match": { "Device Type": "DS Computer" } } ] } } }' | jq '.hits.hits')

#read_no_process_data_from_elastic=$(curl -XPOST "http://172.29.8.87:9200/ip_process_config/_search" -H 'Content-Type: application/json' -d'{  "size": 1000,  "query": {    "bool": {      "must_not": [        {          "term": {            "ProcessType.keyword": ""          }                  },        {          "term": {            " ProcessType.keyword": ""          }          },          {          "term": {            "ProcessType.keyword": "mysql"          }          },        {          "match": {            "Device Type": "DS Computer"          }        }      ]    }  }}'| jq '.hits.hits')

echo "$read_no_process_data_from_elastic" >/elastic_data/services/new_watchman_19-3-20/watchman/ip_no_process.json

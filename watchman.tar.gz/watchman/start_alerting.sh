#!/bin/bash
source /home/aiops/.bash_profile
Token="bot970505280:AAGd7pjs68YTglnLXrEJxJcDIzv-aR2rnug"
ChatID="-383499194"
Msg="$(date) - TANZANIA WATCHMAN DOWN"
msg="$(date) - TANZANIA WATCHMAN HAS BEEN RESTARTED"
STATUS=$(ps -ef | grep node | grep watchman | grep -v timebase|wc -l)
if [ "$STATUS"  -lt 1 ];
then
curl -k -X POST "https://api.telegram.org/$Token/sendMessage" -d chat_id=$ChatID -d text="$Msg";

/usr/lib/node_modules/forever/bin/forever start /home/aiops/watchman/index_2.0.js


sleep 10s
STATUS1=$(ps -ef | grep node | grep watchman | grep -v timebase|wc -l)
if [ "$STATUS1" -gt 1 ];
then
curl -k -X POST "https://api.telegram.org/$Token/sendMessage" -d chat_id=$ChatID -d text="$msg";
else
        exit 0;
      fi
          fi

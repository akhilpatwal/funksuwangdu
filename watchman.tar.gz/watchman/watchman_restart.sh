#!/bin/bash/env bash
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin

source  /root/.bash_profile
udp_connections=$(netstat -uawn | wc -l)
limit=20
path=/elastic_data/services/new_watchman_19-3-20/watchman/ecosystem.config.js
echo "$udp_connections"
if [ $udp_connections -gt  $limit ]; then
        echo "UDP connections is more then limit"
        /opt/node_modules/pm2/bin/pm2 stop $path  && /opt/node_modules/pm2/bin/pm2 start $path
else
        echo "UDP connections is less then limit"
fi
